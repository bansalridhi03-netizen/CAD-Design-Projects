;;; TR8X2_LEADSCREW_NUT_AIA_LAYER_SETUP.lsp
;;; Creates AIA/NCS-style layers and metric drafting setup for the TR8x2 leadscrew nut task.
;;; Command: TR8NUTLAYERS

(defun c:TR8NUTLAYERS (/ acad doc layers ltfile layerData makeLayer ensureLinetype lname color ltype lw plotFlag layerObj)
  (vl-load-com)
  (setq acad (vlax-get-acad-object))
  (setq doc (vla-get-ActiveDocument acad))
  (setq layers (vla-get-Layers doc))
  (setq ltfile "acadiso.lin")

  (defun ensureLinetype (ltname / ltypes)
    (if (and ltname (/= (strcase ltname) "CONTINUOUS"))
      (progn
        (setq ltypes (vla-get-Linetypes doc))
        (if (not (tblsearch "LTYPE" ltname))
          (vl-catch-all-apply 'vla-Load (list ltypes ltname ltfile))
        )
      )
    )
  )

  (defun makeLayer (lname color ltype lw plotFlag / layerObj)
    (ensureLinetype ltype)
    (if (tblsearch "LAYER" lname)
      (setq layerObj (vla-Item layers lname))
      (setq layerObj (vla-Add layers lname))
    )
    (vla-put-Color layerObj color)
    (if ltype (vla-put-Linetype layerObj ltype))
    (vla-put-Lineweight layerObj lw)
    (vla-put-Plottable layerObj (if plotFlag :vlax-true :vlax-false))
    layerObj
  )

  ;; Layer list: (Name Color Linetype Lineweight Plottable)
  ;; Lineweight enum values are hundredths of mm; e.g. 25 = 0.25 mm.
  (setq layerData
    '(
      ("M-EQPM-MODL" 7 "Continuous" 25 T)
      ("M-EQPM-BRASS" 40 "Continuous" 35 T)
      ("M-EQPM-FLNG" 2 "Continuous" 30 T)
      ("M-EQPM-BOSS" 3 "Continuous" 25 T)
      ("M-EQPM-THRD" 6 "Continuous" 18 T)
      ("M-EQPM-HOLE" 4 "Continuous" 18 T)
      ("M-DETL-OBJT" 7 "Continuous" 25 T)
      ("M-DETL-HIDE" 5 "Hidden2" 18 T)
      ("M-DETL-CNTR" 3 "Center2" 18 T)
      ("M-DETL-HATC" 6 "Continuous" 13 T)
      ("M-DETL-SECT" 1 "Continuous" 50 T)
      ("G-ANNO-TEXT" 2 "Continuous" 18 T)
      ("G-ANNO-DIM" 4 "Continuous" 18 T)
      ("G-ANNO-LABL" 2 "Continuous" 25 T)
      ("G-ANNO-SYMB" 3 "Continuous" 18 T)
      ("G-ANNO-TTLB" 7 "Continuous" 25 T)
      ("VIEWPORT" 3 "Continuous" 0 NIL)
    )
  )

  (foreach item layerData
    (makeLayer (nth 0 item) (nth 1 item) (nth 2 item) (nth 3 item) (nth 4 item))
  )

  ;; Metric drawing/display variables.
  (setvar "INSUNITS" 4)
  (setvar "MEASUREMENT" 1)
  (setvar "DISPSILH" 1)
  (setvar "ISOLINES" 0)
  (setvar "LTSCALE" 1.0)
  (setvar "PSLTSCALE" 1)
  (setvar "MSLTSCALE" 1)

  ;; Text styles. Arial may resolve to arial.ttf depending on AutoCAD installation.
  (if (not (tblsearch "STYLE" "Standard"))
    (command "_.-STYLE" "Standard" "arial.ttf" 2.5 1.0 0.0 "N" "N")
    (progn
      (setvar "TEXTSTYLE" "Standard")
      (command "_.-STYLE" "Standard" "arial.ttf" 2.5 1.0 0.0 "N" "N")
    )
  )
  (if (not (tblsearch "STYLE" "Label"))
    (command "_.-STYLE" "Label" "arial.ttf" 5.0 1.0 0.0 "N" "N")
    (command "_.-STYLE" "Label" "arial.ttf" 5.0 1.0 0.0 "N" "N")
  )

  ;; Dimension style setup.
  (setvar "DIMTXSTY" "Standard")
  (setvar "DIMTXT" 2.5)
  (setvar "DIMASZ" 1.25)
  (setvar "DIMEXO" 1.25)
  (setvar "DIMEXE" 1.25)
  (setvar "DIMGAP" 1.25)
  (setvar "DIMCEN" 1.25)
  (setvar "DIMTAD" 1)       ;; text above dimension line
  (setvar "DIMTIH" 0)       ;; align text with dimension line inside extensions
  (setvar "DIMTOH" 0)       ;; align text with dimension line outside extensions
  (setvar "DIMCLRD" 256)
  (setvar "DIMCLRE" 256)
  (setvar "DIMCLRT" 256)
  (setvar "DIMLWD" -2)
  (setvar "DIMLWE" -2)
  (setvar "DIMADEC" 2)
  (setvar "DIMDEC" 2)
  (command "_.-DIMSTYLE" "_Save" "AIA-MM-1_25" "_Yes")

  ;; Set a useful current layer.
  (setvar "CLAYER" "M-EQPM-MODL")
  (princ "\nTR8x2 leadscrew nut AIA layers, text styles, dimension style, and metric display variables created. Command complete: TR8NUTLAYERS")
  (princ)
)

(princ "\nLoaded TR8X2_LEADSCREW_NUT_AIA_LAYER_SETUP.lsp. Run command TR8NUTLAYERS to create layers and setup.")
(princ)
