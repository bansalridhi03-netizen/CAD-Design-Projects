; PRO_TREE_SAW_AIA_LAYER_SETUP.lsp
; Creates AIA/NCS-style layers, text styles, dimension style, and drafting variables
; for the Pro Tree Saw 330MM Detail task.
; Command: TREESAWLAYERS

(vl-load-com)

(defun pts-load-linetype (lt /)
  (if (not (tblsearch "LTYPE" lt))
    (progn
      (vl-catch-all-apply 'command (list "_.-LINETYPE" "_Load" lt "acadiso.lin" ""))
      (if (not (tblsearch "LTYPE" lt))
        (vl-catch-all-apply 'command (list "_.-LINETYPE" "_Load" lt "acad.lin" ""))
      )
    )
  )
)

(defun pts-make-layer (name color ltype lw plot / doc lays lay)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq lays (vla-get-Layers doc))
  (if (not (tblsearch "LAYER" name))
    (setq lay (vla-add lays name))
    (setq lay (vla-item lays name))
  )
  (vla-put-Color lay color)
  (if ltype
    (progn
      (pts-load-linetype ltype)
      (if (tblsearch "LTYPE" ltype) (vla-put-Linetype lay ltype))
    )
  )
  (if lw (vla-put-Lineweight lay lw))
  (vla-put-Plottable lay (if plot :vlax-true :vlax-false))
  lay
)

(defun pts-make-textstyle (name font height / ent)
  (if (tblsearch "STYLE" name)
    (progn
      (setq ent (entget (tblobjname "STYLE" name)))
      (if (assoc 40 ent) (setq ent (subst (cons 40 height) (assoc 40 ent) ent)))
      (if (assoc 3 ent) (setq ent (subst (cons 3 font) (assoc 3 ent) ent)))
      (entmod ent)
    )
    (entmake
      (list
        (cons 0 "STYLE")
        (cons 100 "AcDbSymbolTableRecord")
        (cons 100 "AcDbTextStyleTableRecord")
        (cons 2 name)
        (cons 70 0)
        (cons 40 height)
        (cons 41 1.0)
        (cons 50 0.0)
        (cons 71 0)
        (cons 42 height)
        (cons 3 font)
        (cons 4 "")
      )
    )
  )
)

(defun pts-set-dimstyle (/)
  (pts-make-textstyle "Standard" "arial.ttf" 2.5)
  (pts-make-textstyle "Label" "arial.ttf" 5.0)
  (setvar "DIMTXSTY" "Standard")
  (setvar "DIMTXT" 2.5)
  (setvar "DIMASZ" 1.25)
  (setvar "DIMEXO" 1.25)
  (setvar "DIMEXE" 1.25)
  (setvar "DIMGAP" 1.25)
  (setvar "DIMCEN" 1.25)
  (setvar "DIMTAD" 1)
  (setvar "DIMTIH" 0)
  (setvar "DIMTOH" 0)
  (setvar "DIMCLRD" 256)
  (setvar "DIMCLRE" 256)
  (setvar "DIMCLRT" 256)
  (setvar "DIMLWD" -2)
  (setvar "DIMLWE" -2)
  (vl-catch-all-apply 'command (list "_.-DIMSTYLE" "_Save" "AIA-MM-1_25" "_Yes"))
)

(defun c:TREESAWLAYERS (/)
  ; Lineweight enum values are hundredths of millimeters in AutoCAD COM.
  (pts-load-linetype "Continuous")
  (pts-load-linetype "Hidden2")
  (pts-load-linetype "Center2")

  ; Product model layers
  (pts-make-layer "M-TOOL-MODL" 7 "Continuous" 25 T)
  (pts-make-layer "M-TOOL-BLADE" 8 "Continuous" 35 T)
  (pts-make-layer "M-TOOL-TEETH" 1 "Continuous" 25 T)
  (pts-make-layer "M-TOOL-HNDL" 30 "Continuous" 25 T)
  (pts-make-layer "M-TOOL-FAST" 4 "Continuous" 18 T)
  (pts-make-layer "M-TOOL-SLOT" 5 "Continuous" 18 T)

  ; Detail/view layers
  (pts-make-layer "M-DETL-OBJT" 7 "Continuous" 25 T)
  (pts-make-layer "M-DETL-THIN" 8 "Continuous" 18 T)
  (pts-make-layer "M-DETL-HIDE" 5 "Hidden2" 18 T)
  (pts-make-layer "M-DETL-CNTR" 3 "Center2" 18 T)
  (pts-make-layer "M-DETL-DETAIL" 6 "Continuous" 25 T)
  (pts-make-layer "M-DETL-ISO" 9 "Continuous" 18 T)

  ; Annotation and sheet layers
  (pts-make-layer "G-ANNO-TEXT" 2 "Continuous" 18 T)
  (pts-make-layer "G-ANNO-DIM" 4 "Continuous" 18 T)
  (pts-make-layer "G-ANNO-LABL" 2 "Continuous" 25 T)
  (pts-make-layer "G-ANNO-SYMB" 3 "Continuous" 18 T)
  (pts-make-layer "G-ANNO-TTLB" 7 "Continuous" 25 T)
  (pts-make-layer "VIEWPORT" 3 "Continuous" 0 nil)

  ; Metric drawing variables and visual cleanup
  (setvar "INSUNITS" 4)
  (setvar "MEASUREMENT" 1)
  (setvar "DISPSILH" 1)
  (setvar "ISOLINES" 0)
  (setvar "LTSCALE" 1)
  (setvar "PSLTSCALE" 1)
  (setvar "MSLTSCALE" 1)
  (setvar "CELAYER" "M-TOOL-MODL")

  (pts-set-dimstyle)
  (princ "\nPro Tree Saw AIA/NCS layers, text styles, dimension style, and variables have been created.")
  (princ "\nUse command TREESAWLAYERS to run this setup again.")
  (princ)
)

(princ "\nLoaded PRO_TREE_SAW_AIA_LAYER_SETUP.lsp. Type TREESAWLAYERS to create the layers and setup styles.")
(princ)
