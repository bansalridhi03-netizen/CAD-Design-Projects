$fn =48;

//parameters
p = "a"; //change this--a, b, h, c

hr = 15;
wt = 3;
nr = 6;
nc = 4;
pd = 5;
mg = 8;
tol = 0.2;

dd = 8;
dn = 18;
dw = 28;

ph = pd - tol;
cd = 3;

sr = 5;
sh = 24;
al = 38;
ar = 4;

cr = 22;
ch = 38;
cw = 2.4;


//derived

ha = hr * cos(30);
cp = 2 * ha + wt;
xs = cp * cos(30);
ys = cp;
ec = dd + tol + mg;

pw = 2 * ec + 2 * hr + (nc - 1) * xs;
pl = 2 * ec + 2 * ha + (nr - 1) * ys + (nc > 1 ? ys/2 : 0);


//shapes

module hx(r = hr){
    polygon([for(i = [0:5])[r * cos(60 * i), r * sin(60 * i)]]);
}

module mr(y){
    polygon([[pw, y - dn/2], [pw + dd, y - dw/2], [pw + dd, y + dw/2], [pw, y + dn/2]]);
}

module mt(x){
    polygon([[x - dn/2, pl], [x - dw/2, pl + dd], [x + dw/2, pl + dd], [x + dn/2, pl]]);
}

module fl(y){
    polygon([[-.01, y - (dn + 2 * tol)/2], [dd + tol, y - (dw + 2 * tol)/2], [dd + tol, y + (dw + 2 * tol)/2], [-.01, y + (dn + 2 * tol)/2]]);
}

module fb(x){
    polygon([[x - (dn + 2 * tol)/2, -0.01], [x - (dw + 2 * tol)/2, dd + tol], [x + (dw + 2 * tol)/2, dd + tol], [x + (dn + 2 * tol)/2, -0.01]]);
}

//baseplate

module base(){
    linear_extrude(pd)
    difference(){
        union(){
            square([pw, pl]);          
            mr(pl/2);            
            mt(pw/2);
        }
        
        fl(pl/2);
        fb(pw/2);
        
        for(c = [0:nc-1])
            for(r = [0:nr-1])
                translate([ec + hr+ + c * xs, ec + ha + r * ys + ((c%2) * ys/2)])
                hx(hr);
    }
}

//attachment plug

module plug(){
    linear_extrude(ph)
    hx(hr - tol);
}    

module cap(){
    translate([0,0,ph])
    linear_extrude(cd)
    hx(hr + 2.5);
} 


// hook

module hook(){
    union(){
        plug();
        cap();
        
        translate([0,0,ph+cd])
        cylinder(h=sh,r=sr);
        
        translate([0,0,ph+cd+sh])
        rotate([0,90,0])
        cylinder(h=al,r=ar); 

        translate([al,0,ph+cd+sh])
        sphere(r=ar);       
        
    }
}    
        

//cup

module cup(){
    union(){
        plug();
        cap();

        translate([0,0,ph+cd])
        difference(){
            cylinder(h=ch,r=cr);
            translate([0,0,cw])
            cylinder(h=ch+0.1,r=cr-cw);
        }
    }
}

//output

if(p=="b")base();
else if(p=="h")hook();
else if(p=="c")cup();
else {
    base();
    translate([pw+45,25,0])hook();
    translate([pw+45,95,0])cup();
}



















