////parametric involute spur gear

$fn= 96;

//Default user parameters 
gear_module = 2;
teeth = 20;
thickness = 8;
pressure_angle =20;
backlash = 0.1;
clearance = 0.2;
bore_d = 5;
hub_d = 12;
hub_h = 5;
involute_steps =10; 

//view
spur_gear();

//Math helper functions
function clamp(x, lo, hi)=min(max(x, lo), hi); //limits x so stay between lo and hi
function rad_to_deg(a) = a * 180 / PI; //convert rad to degree
function polar_xy(r, a_deg) = [r * cos(a_deg), r * sin(a_deg)]; //converts polar coordinates into[x,y]
function involute_angle_deg(r, rb) = 
    (r <= rb) ? 0 :
    let(t  = sqrt((r /rb) * (r/rb) -1))
    rad_to_deg(t) - atan(t);  //calculate involute angle in degree
function lerp(a, b, u) = a + (b -a) * u; //interpolate between a & b using factor u

//2D tooth profile to get one tooth
module involute_tooth_2d(
gear_module = 2,
teeth = 20,
pressure_angle =20,
backlash = 0.1,
clearance = 0.2,
involute_steps =10
){
   //calculate important gear radii
   pitch_r = gear_module * teeth /2;
   base_r = pitch_r * cos(pressure_angle);
   add_r =  pitch_r + gear_module;
   root_r = max(0.05, pitch_r - (1.25 * gear_module + clearance));
    
   //calculate tooth thickness at the pitch circle
   circular_pitch = PI * gear_module;
   tooth_thick_at_pitch = max(0.01, circular_pitch / 2 - backlash);
   half_tooth_angle =  rad_to_deg(tooth_thick_at_pitch / pitch_r)/2;
    
   //calulate involute position at pitch circle
   inv_pitch = involute_angle_deg(pitch_r, base_r);
   start_r = max(root_r, base_r);    
    
   //function gives half tooth angle at any radius
   function flank_half_angle(r)=
        half_tooth_angle + inv_pitch - involute_angle_deg(max(r, base_r), base_r);
    
   //get tooth angle at root and outer radius
   root_half_angle = flank_half_angle(start_r);
   add_half_angle = flank_half_angle(add_r);
    
   //make sure to get points to make a smooth tooth
   steps = max(3, involute_steps);
   
   //create left side of tooth from bottom to top
   left_flank = [
        for(i = [0 : steps])
            let(r = lerp(start_r, add_r, i /steps))
            polar_xy(r, -flank_half_angle(r))  
   ];
    
   //create small curved top of tooth
   top_arc = [
        for(i = [1 : steps - 1])
            let(a = lerp(-add_half_angle, add_half_angle, i / steps))
            polar_xy(add_r, a)         
        ];
       
   //create right side of tooth from top back to bottom
   right_flank = [
        for(i = [steps : -1 : 0])
            let(r = lerp(start_r, add_r, i /steps))
            polar_xy(r, flank_half_angle(r))  
        ];  
        
   //root points add to close the tooth shape 
   root_right = [polar_xy(root_r, root_half_angle)];     
   root_left = [polar_xy(root_r, -root_half_angle)];   
 
   //join all points into one 2D tooth polygon
   polygon(points = concat(root_left, left_flank, top_arc, right_flank, root_right));
        
}

//main module to develop gear 

module spur_gear(
    gear_module = 2,
    teeth = 20,
    thickness = 8,
    pressure_angle =20,
    backlash = 0.1,
    clearance = 0.2,
    bore_d = 5,
    hub_d = 12,
    hub_h = 5,
    involute_steps =10 
){
    //Calculate main gear diameters
    pitch_d = gear_module * teeth;
    pitch_r  = pitch_d/2;
    base_d = pitch_d * cos(pressure_angle);
    addendum_d = pitch_d + 2* gear_module;
    root_d = max(0.1, pitch_d - 2 *(1.25  * gear_module + clearance));
    root_r = root_d/2;
    
    //Print calculated dimentions in console
    echo(pitch_d = pitch_d);
    echo(base_d = base_d);
    echo(addendum_d = addendum_d);
    echo(root_d = root_d);
    
   //checking user inputs valid before making the gear
    assert(gear_module > 0, "gear modulus must be greater than 0");
    assert(teeth >= 6, "Use at least 6 teeth for a robust involute gear");
    assert(thickness > 0, "thickness must be greater than 0");
    assert(pressure_angle > 0 && pressure_angle < 45, "pressure angle should usually between 14.5 and 25 degrees");
    assert(bore_d >= 0, "bore_d cannot be negative");
    assert(hub_d >= 0, "hub_d cannot be negative");
    assert(hub_h >= 0, "hub_h cannot be negative");
    assert(root_d > bore_d, "bore_d is too large for the computer root diameter");
    
    //subtract bore hole from the the full gear shape 
    difference(){
        //combine gear body, teeth, hub
        union(){
            //make 2D gear shape (add all teeth) and extrude to make 3D
            linear_extrude(height = thickness, center = true, convexity = 10){
                union(){
                    
                    circle(r= root_r);
                    
                    for (i = [0 : teeth - 1]){
                        rotate(i * 360 / teeth)
                            involute_tooth_2d(
                                gear_module = gear_module,
                                teeth = teeth,
                                pressure_angle = pressure_angle,
                                backlash = backlash,
                                clearance = clearance,
                                involute_steps = involute_steps                        
                            );              
                        }           
                    }         
                }
                
                //Add center hub if hub size is geater than zero
                if (hub_d > 0 && hub_h > 0){
                    cylinder(d = hub_d, h = thickness + hub_h, center =  true);                    
                    }  
            }
            
            //cut bore hole through gear and hub
            if (bore_d > 0){
                cylinder(d = bore_d, h = thickness + hub_h + 2, center =  true);
                }       
        }

    }
    
    
    
    
    