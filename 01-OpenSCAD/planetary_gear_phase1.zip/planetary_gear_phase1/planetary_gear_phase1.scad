//planetary_gear_phase1
$fn = 128;

////parametric section
outer_diameter = 200.0;
wall_thickness = 12.0;
base_plate_thickness = 8.0;

bolt_hole_count = 8;
bolt_hole_diameter = 6.0;
bolt_circle_diameter = 185.0;

ring_internal_diameter = 150.0;
ring_outer_diameter = 160.0;

gear_height = 40.0;
sun_gear_diameter = 48.0;
center_bore_diameter = 18.0;

planet_gear_count = 4;
planet_gear_diameter = 50.0;
planet_center_radius = 50.0;
planet_bore_diameter = 32.0;

carrier_diameter = 155.0;
carrier_thickness = 5.0;

//rendering clearances
render_clearance = 0.30;
z_clearance = 0.20;

eps = 0.05;

////derived render dimentions - for proper rendering
planet_render_diameter = planet_gear_diameter - render_clearance;
ring_internal_render_diameter = ring_internal_diameter + render_clearance;
sun_render_diameter = sun_gear_diameter - render_clearance;

carrier_z = base_plate_thickness + z_clearance;
gear_z = carrier_z + carrier_thickness + z_clearance;

////HELPER MODULE
module bolt_hole_pattern(cut_height){
    for (i = [0 : bolt_hole_count - 1]){
        angle = 360 / bolt_hole_count * i;
        
        rotate([0, 0, angle])
            translate([bolt_circle_diameter / 2, 0, -eps])
                cylinder(
                    d = bolt_hole_diameter,
                    h = cut_height + 2 * eps    
                );
    }
}

module planet_position(){
    for (i = [0 : planet_gear_count - 1]){
        angle = 360 / planet_gear_count * i;
        
        rotate([0, 0, angle])
            translate([planet_center_radius, 0, 0])
                children();    
    }
}

////Structural components 
module base_plate(){
    difference(){
        cylinder(
           d = outer_diameter,
           h = base_plate_thickness    
        );  
        bolt_hole_pattern(base_plate_thickness);
        
        translate([0, 0, -eps])
            cylinder(
                d = center_bore_diameter,
                h = base_plate_thickness + 2 * eps   
        ); 
    }
}

module outer_casting_wall(){
    difference(){
        cylinder(
           d = outer_diameter,
           h = gear_height + carrier_thickness + 2 * z_clearance    
        );  
        
        translate([0, 0, -eps])
            cylinder(
                d = outer_diameter - 2 * wall_thickness,
                h = gear_height + carrier_thickness + 2 * z_clearance + 2 * eps   
        ); 
    }    
}

module carrier_plate(){
    difference(){
        cylinder(
           d = carrier_diameter,
           h = carrier_thickness    
        );  
        
        translate([0, 0, -eps])
            cylinder(
                d = center_bore_diameter + render_clearance,
                h = carrier_thickness + 2 * eps   
        );   
       
       planet_position()
            translate([0, 0, -eps])
            cylinder(
                d = planet_bore_diameter + render_clearance,
                h = carrier_thickness + 2 * eps   
        );         
    }
}

module ring_gear_envelop(){
    difference(){
        cylinder(
           d = ring_outer_diameter,
           h = gear_height    
        );
        translate([0, 0, -eps])
            cylinder(
                d = ring_internal_render_diameter,
                h = gear_height + 2 * eps   
        );         
    }
}

module sun_gear_placeholder(){
    difference(){
        cylinder(
           d = sun_render_diameter,
           h = gear_height    
        );
        translate([0, 0, -eps])
            cylinder(
                d = center_bore_diameter,
                h = gear_height + 2 * eps   
        );         
    }    
}

module planet_gear_placeholder(){
    difference(){
        cylinder(
           d = planet_render_diameter,
           h = gear_height    
        );
        translate([0, 0, -eps])
            cylinder(
                d = planet_bore_diameter,
                h = gear_height + 2 * eps   
        );         
    }      
}
////
module planetary_gear_phase_1(){
    base_plate();

    translate([0, 0, base_plate_thickness - eps])
        outer_casting_wall();

    translate([0, 0, carrier_z])
        carrier_plate();

    translate([0, 0, gear_z])
        ring_gear_envelop();

    translate([0, 0, gear_z])
        sun_gear_placeholder();

    translate([0, 0, gear_z])
        planet_position()
            planet_gear_placeholder();
}
planetary_gear_phase_1();