//soap dish 
$fn = 96;

////Dimensions
outer_length = 112;
outer_width = 82;
outer_height= 28;
outer_radius = 10;
wall_thickness = 4;
base_thickness = 5;

inner_length = outer_length - 2 * wall_thickness;
inner_width = outer_width - 2 * wall_thickness;
inner_height = outer_height - base_thickness;
inner_radius = outer_radius - wall_thickness;

rib_count = 6;
rib_width = 6;
rib_height = 5;

gap_count = rib_count + 1;
gap_width = (inner_length - rib_count * rib_width) / gap_count;

side_rail_width = rib_width;

slot_width = gap_width;
slot_length = inner_width - 2 * side_rail_width;

// Small overlap for clean union 
grate_embed = 0.20;
eps = 0.05;

foot_radius = 5;
foot_height = 5;
foot_offset_x = 12;
foot_offset_y = 10;

////Helpers

module rounded_rect_2d(l, w, r){
    hull(){
        translate([ l/2 - r, w/2 - r]) circle(r = r);
        translate([ -l/2 + r, w/2 - r]) circle(r = r);
        translate([ l/2 - r, -w/2 + r]) circle(r = r);
        translate([ -l/2 + r, -w/2 + r]) circle(r = r);
   }
}

module rounded_box(l, w, h, r){
    linear_extrude(height = h)
        rounded_rect_2d(l, w, r);
}

////Outer shell with hollow cavity

module shell_body(){
    difference(){
        //outer body
        rounded_box(
            outer_length,
            outer_width,
            outer_height,
            outer_radius
        );
        
        //inner cavity
        translate([0, 0, base_thickness])
        rounded_box(
            inner_length,
            inner_width,
            inner_height + eps,
            inner_radius
        );
   }
}

/////Top grate layer

module top_grate_layer(){
    translate([0, 0, base_thickness - grate_embed])
        rounded_box(
            inner_length,
            inner_width,
            rib_height + grate_embed,
            inner_radius
        );
}

////Drain slots

module drain_slots(){
    for (i = [0 : gap_count - 1]){
        x_pos = -inner_length / 2 + gap_width / 2 + i * (rib_width + gap_width);
        
        translate([x_pos, 0, (base_thickness + rib_height) / 2])
            cube(
                [
                    slot_width + eps,
                    slot_length,
                    base_thickness + rib_height + 2 * eps
                ],
                center = true
            );
    }
}

/////Under feet

module feet(){
    for (x_pos = [-outer_length / 2 + foot_offset_x, outer_length / 2 - foot_offset_x]) {
        for (y_pos = [-outer_width / 2 + foot_offset_y, outer_width / 2 - foot_offset_y]) {
            translate([x_pos, y_pos, -foot_height])
                cylinder(
                    h = foot_height,
                    r = foot_radius
                );
        }
    }
}

///Final model
module soap_dish(){
    union() {
        difference(){
            union(){
                shell_body();
                top_grate_layer();
            }
            drain_slots();   
        }
        feet();
    }
}

render(convexity = 10)
    soap_dish();









