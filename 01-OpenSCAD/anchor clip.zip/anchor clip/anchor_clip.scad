////Anchor clip drawing

resolution = 96;
$fn = resolution;
arc_step = 360 / resolution;

//parameters 

part_width = 40;
thickness = 8;
body_length = 58;
slot_width = 6.6;
slot_length = 20;
slot_center_x = 38;
slot_spacing = 18;
cut_clearance = 0.2;
rear_tab_thickness = 10;
rear_tab_height = 25;
rear_tab_notch_width = 14;
rear_tab_notch_height = 10;
rear_tab_fillet_radius = 3;
rear_outer_curve_radius = 3;
tail_angle = 60;
body_tail_inner_radius = 3;
tail_length = 50;
tail_tip_radius = 20;
tail_root_length = 10;
tail_hole_diameter = 25;
tail_hole_center_x = 30;
keyway_width = 5;
keyway_angle = -45;
fillet_overlap  = 0.2;
tail_join_overlap = 0.8;

//2D shape for horizontal base body
//top at Z = 0 and thickness extends downward
module body_side_profile_2d(){
    r = rear_outer_curve_radius;
    
    polygon(
        points = concat(
            [
                [0,0],
                [body_length,0],
                [body_length, -thickness],
                [r, -thickness]   
            ],
            [
                for (a = [-90 : -arc_step : -180])
                    [
                        r + r * cos(a),
                        -thickness + r + r* sin(a)
                    ]
             ],
             [
                [0,0]   
             ]
        )
    );    
  }
  
//extrude 2D base profile across part width
module body_plate_solid(){
    rotate([90, 0, 0])
        linear_extrude(height = part_width, center = true)
            body_side_profile_2d();  
}  

//Creating 2D shape for rounded slots
module rounded_slot_2d(length, width){
    hull(){
        translate([-length / 2 + width /2 , 0])
        circle (d = width);
        
        translate([length / 2 - width /2 , 0])
        circle (d = width);
      }
 }
 
 //cut slots in plate
 module body_slots(){
     translate([slot_center_x, -slot_spacing / 2, -thickness - cut_clearance])
        linear_extrude(height = thickness + 2 * cut_clearance)
            rounded_slot_2d(slot_length, slot_width);
     
     translate([slot_center_x, slot_spacing / 2, -thickness - cut_clearance])
        linear_extrude(height = thickness + 2 * cut_clearance)
            rounded_slot_2d(slot_length, slot_width);
 }
 

//bottom body base with slots
module body_plate_with_slots(){
    difference(){
        body_plate_solid();
        body_slots();
    }
} 
 

//create upright tab at back of base
module rear_upright_tab(){
    difference(){
        translate([0, -part_width / 2, 0])
            cube([
               rear_tab_thickness,
               part_width,
               rear_tab_height 
        ]);
        
        translate([
            -cut_clearance,
            -rear_tab_notch_width / 2,
            rear_tab_height - rear_tab_notch_height     
        ]) 
            cube([
                rear_tab_thickness + 2 * cut_clearance,
                rear_tab_notch_width,
                rear_tab_notch_height + cut_clearance
        ]);
     }
}

//Extrude X-Y profile in Y direction
module extrude_profile_along_y(points_xz, width){
    point_count = len(points_xz);
    
    polyhedron(
        points  = concat(
            [
                for (p = points_xz)
                    [p[0], -width / 2, p[1]]
            ],
            [
                for (p = points_xz)
                    [p[0], width / 2, p[1]]
            ]   
        ),
         faces = concat(
              [
                [for (i = [0: point_count - 1]) i]
              ],
              [
                [for (i = [point_count - 1 : -1 : 0]) i + point_count]
              ],   
              [
                for (i = [0: point_count - 1])
                    [
                        i,
                        (i + 1) % point_count,
                        ((i + 1) % point_count) + point_count,
                        i + point_count
                    ]
              ]             
    )
  );
}

//Add a fillet where rear tab meets the base
module rear_tab_fillet(){
    r = rear_tab_fillet_radius;
    o = fillet_overlap;
    //cx = rear_tab_thickness + r;
    //cz = r;
    
//    points_xz = concat(
//        [
//            [rear_tab_thickness, 0],
//            [rear_tab_thickness + r, 0]
//        ],
//        [
//            for (a = [-90 : -arc_step : -180])
//                [
//                    cx + r * cos(a),
//                    cz + r * sin(a)
//                ]
//        ],
//        [
//            [rear_tab_thickness, 0]
//        ]
//    );
            
//    extrude_profile_along_y(points_xz, part_width);
    translate([0, part_width / 2 + o, 0])
        rotate([90, 0, 0])
            linear_extrude(height = part_width + 2 * o)
                polygon(
                    points = concat(
        [
            [rear_tab_thickness - o, -o],
            [rear_tab_thickness + r, -o]
        ],
        [
            for (a = [-90 : -arc_step : -180])
                [
                    rear_tab_thickness + r + r * cos(a),
                    r + r * sin(a)
                ]
        ],
        [
            [rear_tab_thickness - o, r + o]
        ]
    )         
  );
}


//curve bend between body and tail part
module body_tail_bend(){
    inner_r = body_tail_inner_radius;
    outer_r = body_tail_inner_radius + thickness;
    o = fillet_overlap;
    
    cx = body_length;
    cz = -outer_r;
    
    top_arc = [
        for (a = [0 : arc_step : tail_angle])
            [
                cx + outer_r * sin(a),
                cz + outer_r * cos(a)
            ]
    ];
     inner_arc = [
        for (a = [tail_angle : -arc_step : 0])
            [
                cx + inner_r * sin(a),
                cz + inner_r * cos(a)
            ]
    ];
    bend_profile = concat(top_arc, inner_arc);
    //extrude_profile_along_y(bend_profile, part_width);
        
   translate([0, part_width / 2 + o, 0])
        rotate([90, 0, 0])
            linear_extrude(height = part_width + 2 * o)
                polygon(points = bend_profile);
}

//Create 2D outline of tail
module tail_outline_2d(){
    hull(){
        translate([0, -part_width / 2])
            square([tail_root_length, part_width]);
        
        translate([tail_length - tail_tip_radius, 0])
            circle(r = tail_tip_radius);
    }
}


//angled tail as a solid piece without any cutouts
module bent_tail_solid(){
    outer_r = body_tail_inner_radius + thickness;
    
    tail_start_x = body_length + outer_r * sin(tail_angle);
    tail_start_z = -outer_r + outer_r * cos(tail_angle);
    
    translate([tail_start_x, 0, tail_start_z])
        rotate([0, tail_angle, 0])
            translate([0, 0, -thickness])
                linear_extrude(height = thickness)
                    tail_outline_2d();
}

//Defining circular hole and key way cutout in tail
module tail_cutouts_2d(){
    translate([tail_hole_center_x, 0])
        circle(d = tail_hole_diameter);
    
    translate([tail_hole_center_x, 0])
        rotate(keyway_angle)
            translate([tail_hole_diameter / 2 - 0.2, -keyway_width / 2])
                square([
                    tail_tip_radius +10,
                    keyway_width
                ]);
}

//Final tail with cutouts
module bent_tail_finished(){
    outer_r = body_tail_inner_radius + thickness;
    
    tail_start_x = body_length + outer_r * sin(tail_angle);
    tail_start_z = -outer_r + outer_r * cos(tail_angle);
    
    translate([tail_start_x, 0, tail_start_z])
        rotate([0, tail_angle, 0])
            translate([-tail_join_overlap, 0, 0])
                difference(){
                    translate([0, 0, -thickness])
                        linear_extrude(height = thickness)
                            tail_outline_2d();
   
                    translate([tail_join_overlap, 0, -thickness - cut_clearance])
                        linear_extrude(height = thickness + 2 * cut_clearance)
                            tail_cutouts_2d();
              }
}

//print
union(){
    body_plate_with_slots();
    rear_upright_tab();
    rear_tab_fillet();
    body_tail_bend();
    //bent_tail_solid();
    bent_tail_finished();
}
        
        
        
        
        
        
        
        
        
        
        
        
        

