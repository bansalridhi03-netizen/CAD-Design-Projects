
$fn = 96;

//Parameters

br = 80;
wt = 4;
ir = br - wt;

lip = 3;

sr = 24;
sh = 13;

fr = 48;
fh = 6;
er = 1.5;

cv = 10;

ht = 5;
hl = 22;
hz = -22;
hs = 30;
ho = 36;

pc = 12;
pw = 18;
ph = 30;
pd = 1.5;
pr = 2.5;
rc = 1;
rs = 34;
pz = -42;
pa = 180 / pc;

e = 0.05;

//Helpers

//flat rounded rectangle
module rr(w, h, r){
    hull(){
        translate([w/2-r, h/2-r]) circle(r);
        translate([-w/2+r, h/2-r]) circle(r); 
        translate([w/2-r, -h/2+r]) circle(r);
        translate([-w/2+r, -h/2+r]) circle(r);        
    }
}


//torus
module tor(R, r){
    rotate_extrude()
        translate([R, 0])
            circle(r);
}
 

//tube - for handles
module tube(pts, r){
    for (i = [0 : len(pts) - 2]){
        hull(){
            translate(pts[i])
                sphere(r);
            
            translate(pts[i + 1])
                sphere(r); 
        }
    }        
}

function arc(cx, cz, r, a1, a2, n) =
    [
        for (i = [0 : n])
            let(a = a1 + (a2 - a1) * i / n)
                [cx + r * cos(a), cz + r * sin(a)]
    ];

function bez(p0, p1, p2, t) = 
    [
        pow(1-t,2)*p0[0] + 2*(1-t)*t*p1[0] + pow(t,2)*p2[0],
        pow(1-t,2)*p0[1] + 2*(1-t)*t*p1[1] + pow(t,2)*p2[1],
        pow(1-t,2)*p0[2] + 2*(1-t)*t*p1[2] + pow(t,2)*p2[2]
    ];
        
//Bowl Shell
module bowl0(){
    difference(){
        intersection(){
            sphere(br);
            
            translate([-br, -br, -br])
                cube([2*br, 2*br, br]);
        }
        
        intersection(){
            sphere(ir);
            
            translate([-br, -br, -br])
                cube([2*br, 2*br, br + e]);
        }
    }
}

//Panels
module pcut(w, h, d, r){
    rotate([0, 90, 0])
        linear_extrude(height = d, center = true)
            rr(h, w, r);
}

module onep(th, zc){
    lr = sqrt(br*br - zc*zc);
    
    ta = asin(zc / br);
    
    rotate([0, 0, th])
        translate([lr, 0, zc])
            rotate([0, -ta, 0])
                translate([-pd/2 + e, 0, 0])
                    pcut(pw, ph, pd + 2*e, pr);
}

module patt(){
    for (row =[0: rc - 1]){
        zc = pz + (row - (rc - 1) / 2) * rs;
        
        for (i = [0 : pc - 1]){
            th = i * 360 / pc + pa;
            onep(th, zc);
        }
    }
}


module bowl(){
    difference(){
        bowl0();
        patt();
    }
}


//Rim
module rim(){
    tor(br, lip);
}


//Foot
module base(){
    z0 = -br - sh - fh;
    z1 = z0 + fh;
    
    r2 = er;
    side = fr - r2;
    
    bot = arc(side, z0 + r2, r2, -90, 0, 16);
    top = arc(side, z1 - r2, r2, 0, 90, 16);
    
    rotate_extrude()
        polygon(
            concat(
                [[0, z0], [side, z0]],
                bot,
                [[fr, z1 - r2]],
                top,
                [[0, z1]]
                )
        );
}

module stem(){
    zb = -br -sh;
    
    translate([0, 0, zb])
        cylinder(
            h = sh +e,
            r = sr
    );
}

module cove(){
    z0 = -br  - 2;
    z1 = -br + cv;
    
    r0  = sr;
    r1 = sr + cv;
    
    ca = arc(r1, z0, cv, 180, 90, 24);
    
    rotate_extrude()
        polygon(
            concat(
                [
                    [0, z0 - cv], 
                    [r0, z0 - cv],
                    [r0, z0]
                ],
                ca,
                [[0, z1]]
                )   
        );    
}

module foot(){
    union(){
        base();
        stem();
        cove();
    }
}

module handle(){
    zt = hz + hs / 2;
    zb = hz - hs / 2;
    
    xt = sqrt(br*br - zt*zt) - 1;
    xb = sqrt(br*br - zb*zb) - 1;
    
    pt = [xt, 0, zt];
    pb = [xb, 0, hz];
    
    x0 = max(xt, xb) + ho;
    pm = [x0, 0, hz];
    
    pts = [
        for (i = [0 : 32])
            bez(pt, pm, pb, i / 32)
        ];
        
        tube(pts, ht);
        
        hull(){
            translate(pt)
                sphere(ht * 1.08);
            
            translate([xt - 7, 0, zt])
                sphere(ht * 1.08);  
        }
      
        hull(){
            translate(pb)
                sphere(ht * 1.08);
            
            translate([xb - 7, 0, zb])
                sphere(ht * 1.08);  
        }     
}   
    
module handles(){
        handle();
    
        rotate([0, 0, 180])
            handle();
}
    

//final assembly
module model(){
    union(){
        bowl();
        rim();
        foot();
        handles();
    }
}

 model();



















    
 